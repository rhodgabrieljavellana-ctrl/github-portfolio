export interface Step {
  id: string;
  phaseId: number;
  title: string;
  subtitle: string;
  description: string;
  systemAction: string;
  completionCredits: number;
  markdownSnippet?: string;
  isUnlocked: boolean;
  isCompleted: boolean;
  tasks: Task[];
  tips: string[];
}

export interface Task {
  id: string;
  label: string;
  completed: boolean;
}

export interface TechBadge {
  name: string;
  category: "languages" | "frameworks" | "tools" | "databases";
  badgeSlug: string;
  hexColor: string;
}

export interface TechCategory {
  id: "languages" | "frameworks" | "tools" | "databases";
  label: string;
  iconName: string;
}

export interface UserData {
  name: string;
  githubUsername: string;
  role: string;
  bioHighlights: string;
  selectedSkills: string[];
  selectedTheme: string;
  experienceLevel: string;
  tone: string;
}

export interface TerminalUpgrade {
  id: string;
  title: string;
  description: string;
  cost: number;
  isPurchased: boolean;
  type: "color-mod" | "crt-filter" | "klaxon-siren" | "audio-freq";
  value: string;
}
