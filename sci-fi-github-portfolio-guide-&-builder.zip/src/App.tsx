import React, { useState, useEffect } from "react";
import { 
  Terminal, 
  Code2, 
  Cpu, 
  Database, 
  Wrench, 
  CheckCircle2, 
  Sparkles, 
  Copy, 
  Check, 
  RotateCcw, 
  Compass, 
  BookOpen, 
  Phone, 
  Mail, 
  User, 
  GraduationCap, 
  ExternalLink,
  Shield,
  Zap,
  Eye,
  CheckCircle,
  Briefcase,
  AlertTriangle
} from "lucide-react";
import { INITIAL_STEPS } from "./data";
import { Step, UserData } from "./types";

export default function App() {
  // Primary User Data: pre-populated with Rhod Gabriel L. Javellana's credentials
  const [userData, setUserData] = useState<UserData>({
    name: "Rhod Gabriel L. Javellana",
    githubUsername: "rhodgabriel-dev",
    role: "Computer Engineer & Full Stack Developer",
    bioHighlights: "20-year-old Bachelor of Science in Computer Engineering candidate. A highly adaptable fast learner skilled in merging microcontroller hardware, circuit design, and IoT with modern full-stack web architectures.",
    selectedSkills: ["TypeScript", "React", "Python", "Docker", "Git", "C++", "PostgreSQL", "SQLite", "Node.js"],
    selectedTheme: "cyberpunk",
    experienceLevel: "Junior/Entry-Level",
    tone: "professional sci-fi",
  });

  const [steps, setSteps] = useState<Step[]>(INITIAL_STEPS);
  const [activeStepId, setActiveStepId] = useState<string>("step_01_repo");
  
  // Custom interface enhancements for accessibility and presentation
  const [highContrastMode, setHighContrastMode] = useState<boolean>(false);
  const [largeTextMode, setLargeTextMode] = useState<boolean>(false);

  // AI Pipeline States
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [synthesizedMarkdown, setSynthesizedMarkdown] = useState<string | null>(null);
  const [copiedStatus, setCopiedStatus] = useState<boolean>(false);
  const [synthesisError, setSynthesisError] = useState<string | null>(null);
  const [copiedContact, setCopiedContact] = useState<boolean>(false);

  // System Logs stream for feedback
  const [activeLogs, setActiveLogs] = useState<string[]>([
    "System Ready. Loaded Portfolio Guide Engine.",
    "Commander Profile set: Rhod Gabriel L. Javellana (Age 20, BSCpE student).",
    "Awaiting checklist execution to synchronize portfolio matrix."
  ]);

  const addLog = (message: string) => {
    setActiveLogs(prev => [message, ...prev.slice(0, 4)]);
  };

  // Compute total progress based on completed tasks
  const allTasks = steps.flatMap(s => s.tasks);
  const completedTasksCount = allTasks.filter(t => t.completed).length;
  const totalTasksCount = allTasks.length;
  const progressPercent = totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0;

  // Toggle tasks inside step guide
  const handleToggleTask = (stepId: string, taskId: string) => {
    setSteps(prevSteps => {
      return prevSteps.map(step => {
        if (step.id === stepId) {
          const updatedTasks = step.tasks.map(t => {
            if (t.id === taskId) {
              const goingToComplete = !t.completed;
              addLog(`Aligned task node: "${t.label}" changed to ${goingToComplete ? 'COMPLETED' : 'PENDING'}`);
              return { ...t, completed: goingToComplete };
            }
            return t;
          });

          const isCompletedNow = updatedTasks.every(t => t.completed);
          if (isCompletedNow && !step.isCompleted) {
            addLog(`🚀 SECURED PHASE: "${step.title}" metrics satisfied!`);
          }

          return { ...step, tasks: updatedTasks, isCompleted: isCompletedNow };
        }
        return step;
      });
    });
  };

  // Handle subsequent stage unlocks dynamically as tasks are checked off
  useEffect(() => {
    setSteps(prev => prev.map((st, i) => {
      if (i === 0) return { ...st, isUnlocked: true };
      const prevStep = prev[i - 1];
      return { ...st, isUnlocked: prevStep.isCompleted };
    }));
  }, [steps]);

  // Request portfolio generation via backend API using developer credentials
  const runAiSynthesis = async () => {
    setIsSynthesizing(true);
    setSynthesisError(null);
    setSynthesizedMarkdown(null);
    addLog("Interfacing server Gemini pipeline to synthesize profile README.md...");

    try {
      const response = await fetch("/api/synthesize-portfolio", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Establishment protocol offline.");
      }

      const resJson = await response.json();
      setSynthesizedMarkdown(resJson.markdown);
      addLog("README successfully drafted. Ready to copy!");
      
      // Mark step 5 completed automatically
      setSteps(prev => prev.map(st => st.id === "step_05_ai" ? {
        ...st,
        isCompleted: true,
        tasks: st.tasks.map(t => ({ ...t, completed: true }))
      } : st));
    } catch (err: any) {
      setSynthesisError(err.message || "Failed to make contact with server pipeline.");
      addLog(`Error syncing Markdown stack: ${err.message}`);
    } finally {
      setIsSynthesizing(false);
    }
  };

  // Copy output markdown directly to clipboard
  const copyToClipboard = () => {
    if (!synthesizedMarkdown) return;
    navigator.clipboard.writeText(synthesizedMarkdown);
    setCopiedStatus(true);
    addLog("Transferred generated Markdown code into Clipboard buffers.");
    setTimeout(() => setCopiedStatus(false), 2000);
  };

  // Instant recruiter-copy button helper
  const copyRecruiterContact = () => {
    const contactText = `Rhod Gabriel L. Javellana
Role: Computer Engineer & Full Stack Developer (BSCpE, Age: 20, Fast Learner)
Phone Contact: 09945886983
Email: rhodgabrieljavellana@gmail.com
GitHub: https://github.com/rhodgabriel-dev`;
    navigator.clipboard.writeText(contactText);
    setCopiedContact(true);
    addLog("Copied recruiter contact card details.");
    setTimeout(() => setCopiedContact(false), 2000);
  };

  const activeStep = steps.find(s => s.id === activeStepId) || steps[0];

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col relative transition-all duration-300 ${
      highContrastMode ? 'contrast-high bg-black text-white' : ''
    }`}>
      
      {/* GLOWING AMBIENT CORE BACKGROUND */}
      <div className="absolute inset-x-0 top-0 h-96 bg-gradient-to-b from-sky-950/20 via-transparent to-transparent pointer-events-none" />

      {/* HEADER SECTION */}
      <header className="border-b border-sky-900/60 bg-slate-900/40 backdrop-blur-md px-6 py-4 relative z-10 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-sky-950 text-sky-400 border border-sky-800">
              <Terminal className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-sky-950 text-sky-350 px-2.5 py-0.5 rounded-full border border-sky-800 font-bold font-mono tracking-wider">
                  PORTFOLIO COGNITIVE RADAR
                </span>
                <span className="text-yellow-400 text-[10px] font-mono font-bold uppercase">
                  No Bloat Mode Live
                </span>
              </div>
              <h1 className="text-xl md:text-2xl font-bold font-mono tracking-tight text-white">
                Rhod Gabriel L. Javellana <span className="text-sky-400 font-normal">| GitHub Profile Guide</span>
              </h1>
            </div>
          </div>

          {/* UTILITY BAR CONSOLE */}
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto justify-end">
            
            {/* Toggle accessibility high contrast */}
            <button
              onClick={() => {
                setHighContrastMode(!highContrastMode);
                addLog(`Contrast Mode updated: ${!highContrastMode ? "Maximum Recruiter Focus Mode" : "Deactivated default contrast overrides"}`);
              }}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                highContrastMode 
                  ? "bg-white text-black border-white shadow-[0_0_15px_#ffffff]" 
                  : "bg-slate-900 border-slate-700 text-slate-350 hover:border-slate-500 hover:text-white"
              }`}
              title="Click here for absolute maximum black/white text contrast!"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{highContrastMode ? "CONTRAST: MAXIMUM" : "OLDER RECRUITER READABLE MODE"}</span>
            </button>

            {/* Toggle scale */}
            <button
              onClick={() => {
                setLargeTextMode(!largeTextMode);
                addLog(`Toggled scaling options: ${!largeTextMode ? "Large 1.25x fonts" : "Default fluid fonts"}`);
              }}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                largeTextMode 
                  ? "bg-sky-500 text-slate-950 border-sky-405 shadow-md font-black" 
                  : "bg-slate-900 border-slate-700 text-slate-350 hover:border-slate-500 hover:text-white"
              }`}
            >
              <span>{largeTextMode ? "TEXT-SIZE: LARGER (XL)" : "TEXT-SIZE: NORMAL"}</span>
            </button>

          </div>
        </div>
      </header>

      {/* TOP SPECIAL NOTIFICATION BAR FOR RECRUITERS & AGENT */}
      <section className="bg-sky-550/15 border-b border-sky-800/40 text-slate-200 px-6 py-2.5 text-xs font-mono scroll-py-1 z-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="bg-emerald-500 text-slate-950 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-widest leading-none">
              BS BSCPE CANDIDATE
            </span>
            <span>📍 Active Sector: <strong>Computer Engineering & Intelligent Systems</strong></span>
            <span>•</span>
            <span className="text-slate-300">Age: <strong>20 Years Old</strong></span>
            <span>•</span>
            <span className="text-indigo-300 font-bold">⚡ Fast Learner Blueprint</span>
          </div>
          <div className="flex items-center gap-2 text-slate-100 font-semibold">
            <span>Call/SMS: <strong className="text-yellow-400">09945886983</strong></span>
            <span className="text-slate-650">|</span>
            <span>Email: <strong className="text-sky-400">rhodgabrieljavellana@gmail.com</strong></span>
          </div>
        </div>
      </section>

      {/* MAIN LAYOUT WRAPPER */}
      <main className={`flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10 ${
        largeTextMode ? "text-lg md:text-xl" : "text-sm"
      }`}>
        
        {/* LEFT COLUMN: HERO BIO & REC-COPY DOSSIER (COL-SPAN-4) */}
        <aside className="lg:col-span-4 flex flex-col gap-6">
          
          {/* USER SPECIFIC BIO DECK */}
          <div className="bg-slate-900/90 border border-sky-800/65 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 right-0 bg-sky-950/80 border-b border-l border-sky-850 px-3 py-1 rounded-bl-xl text-[10px] font-mono uppercase font-bold text-sky-400 tracking-wider">
              System Core User
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-sky-950 border border-sky-800 flex items-center justify-center text-sky-450 font-bold font-mono text-lg">
                  RG
                </div>
                <div>
                  <h2 className="text-base font-bold font-mono tracking-tight text-white uppercase">
                    Rhod Gabriel L. Javellana
                  </h2>
                  <p className="text-xs text-slate-400 font-semibold font-mono">
                    Undergraduate Cadet Class of 2026
                  </p>
                </div>
              </div>

              {/* SPECIFIC RECRUITER BIO FOCUSING ON CORE ATTRIBUTES */}
              <blockquote className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono text-slate-200 relative leading-relaxed">
                <p className="before:content-['“'] before:text-sky-500 before:font-bold before:text-lg after:content-['”'] after:text-sky-500 after:font-bold after:text-lg">
                  Highly persistent 20-year-old Computer Engineering student. Expertly merges digital microcontroller circuits with high-level full-stack web applications. An active student developer who prides himself on being an exceptionally fast systems learner.
                </p>
              </blockquote>

              {/* STATS MATRIX */}
              <div className="space-y-2 bg-slate-950/60 p-3 rounded-xl border border-slate-850 text-xs font-mono">
                <div className="flex justify-between items-center py-1 border-b border-slate-900">
                  <span className="text-slate-400">Main Focus:</span>
                  <span className="font-semibold text-white">Full Stack & Embedded Systems</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-900">
                  <span className="text-slate-400">Current Academic:</span>
                  <span className="font-semibold text-yellow-400">BS Computer Engineering</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-900">
                  <span className="text-slate-400">Age Bracket:</span>
                  <span className="font-semibold text-sky-350">20 Earth Years</span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-400">Git Repository:</span>
                  <a 
                    href="https://github.com/rhodgabriel-dev" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-sky-400 underline font-bold inline-flex items-center gap-1 hover:text-sky-350"
                  >
                    @rhodgabriel-dev <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>

            {/* QUICK COPY RECRUIT CONTACT METRICS BUTTON */}
            <div className="pt-4 mt-2">
              <button
                onClick={copyRecruiterContact}
                className="w-full bg-slate-950 hover:bg-sky-500 hover:text-slate-950 text-sky-400 font-bold font-mono text-xs py-3 px-4 rounded-xl border border-sky-800/80 flex items-center justify-center gap-2 transition-all duration-150 active:scale-95"
              >
                {copiedContact ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>COPIED DOSSIER METRICS!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>QUICK COPY CONTACT (RECRUITER)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* PROGRESS SYNC DASHBOARD */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg font-mono">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-sky-400" />
              <span>TASK COMPLETION SYNCHRONIZER</span>
            </h3>
            
            <p className="text-[11px] text-slate-400 leading-normal mb-4">
              Toggle checklist subdirectives on the central screen as you set up your GitHub workspace to track progress.
            </p>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs text-white">
                <span>PORTFOLIO SYNC RATIO:</span>
                <span className="font-black text-sky-400">{progressPercent}%</span>
              </div>
              <div className="w-full h-2 rounded bg-slate-950 overflow-hidden border border-slate-905">
                <div 
                  className="h-full bg-gradient-to-r from-sky-500 to-indigo-500 transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 pt-1">
                <span>{completedTasksCount} / {totalTasksCount} DIRECTIVES RESOLVED</span>
                <span>{progressPercent === 100 ? "FULLY READY" : "SEQUENCING"}</span>
              </div>
            </div>
          </div>

          {/* LIVE SYSTEM FEED */}
          <div className="flex-1 bg-slate-905/70 border border-slate-850 rounded-2xl p-4 font-mono text-[11px] flex flex-col justify-between gap-4">
            <div>
              <span className="text-[10px] text-slate-400 font-bold block mb-2 uppercase tracking-wide">
                SYSTEM CONSOLE OUTPUT
              </span>
              <div className="space-y-2">
                {activeLogs.map((log, index) => (
                  <div key={index} className="text-slate-300 border-l border-slate-800 pl-2 py-0.5 leading-relaxed">
                    <span className="text-sky-400 font-bold mr-1">&gt;</span> {log}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-950 py-2.5 px-3 rounded border border-slate-900 space-y-1 text-[10px]">
              <div>OPERATOR: <span className="text-slate-300">RHOD GABRIEL L.</span></div>
              <div>ENVIRONMENT: <span className="text-sky-400 font-bold">CLOUD PORT 3000</span></div>
              <div>COGNITIVE SYSTEM: <span className="text-emerald-400 font-bold">GEMINI 3.5 FRAME</span></div>
            </div>
          </div>

        </aside>

        {/* MIDDLE COLUMN: STEP CONFIGURATOR & CUSTOMIZER (COL-SPAN-5) */}
        <section className="lg:col-span-5 flex flex-col gap-6">
          
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 md:p-6 shadow-xl flex-1 flex flex-col justify-between">
            <div className="space-y-5">
              
              {/* COMPONENT STEPS NAVIGATION */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-850">
                <span className="text-xs px-2.5 py-0.5 rounded bg-sky-950 text-sky-350 border border-sky-850 font-mono">
                  STEP {activeStep.phaseId} OF 5
                </span>
                <span className="text-xs text-slate-400 font-mono font-bold">
                  GITHUB LAUNCH SEQUENCE
                </span>
              </div>

              {/* Title descriptions */}
              <div className="space-y-1">
                <h3 className="text-lg font-bold font-mono text-white">
                  {activeStep.title}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/80 p-3.5 rounded-xl border border-slate-850">
                  {activeStep.description}
                </p>
              </div>

              {/* Step Subdirectives Checklist */}
              <div className="space-y-2">
                <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider mb-2 font-mono">
                  SUB-TASKS FOR THIS PHASE:
                </span>
                {activeStep.tasks.map(task => {
                  return (
                    <button
                      key={task.id}
                      onClick={() => handleToggleTask(activeStep.id, task.id)}
                      className={`w-full text-left p-3 rounded-xl border flex items-center justify-between transition-all duration-100 ${
                        task.completed 
                          ? 'bg-emerald-950/20 border-emerald-800/80 text-emerald-350' 
                          : 'bg-slate-950 hover:bg-slate-950/80 border-slate-850 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded flex items-center justify-center border ${
                          task.completed ? 'bg-emerald-500 border-none text-slate-950' : 'bg-slate-900 border-slate-700'
                        }`}>
                          {task.completed && <Check className="w-3.5 h-3.5 stroke-[3px]" />}
                        </div>
                        <span className={`text-xs font-mono ${task.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                          {task.label}
                        </span>
                      </div>
                      <span className={`text-[10px] font-mono tracking-tight font-bold ${
                        task.completed ? 'text-emerald-400' : 'text-sky-400/80'
                      }`}>
                        {task.completed ? "RESOLVED" : "TOGGLE"}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* DYNAMIC FORM VIEWS DEPENDING ON PHASE */}
              {activeStep.id === "step_02_hero" && (
                <div className="space-y-3 bg-slate-950/50 p-4 rounded-xl border border-slate-850">
                  <span className="text-[9px] text-yellow-400 font-mono font-bold uppercase block tracking-wider">
                    Dossier Configuration Parameters
                  </span>
                  
                  <div className="space-y-3 font-mono text-xs">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">YOUR PREFERRED SCREEN NAME</label>
                      <input 
                        type="text"
                        value={userData.name}
                        onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 text-white rounded px-2.5 py-1.5 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">TARGET DEVELOPMENT ROLE TITLE</label>
                      <input 
                        type="text"
                        value={userData.role}
                        onChange={(e) => setUserData({ ...userData, role: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 text-white rounded px-2.5 py-1.5 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">TARGET HIGHLIGHT BIO BIOMETRICS (FOR GITHUB OVERVIEW)</label>
                      <textarea 
                        rows={3}
                        value={userData.bioHighlights}
                        onChange={(e) => setUserData({ ...userData, bioHighlights: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-sky-500 text-white rounded px-2.5 py-1.5 leading-relaxed focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeStep.id === "step_03_badges" && (
                <div className="space-y-3 bg-slate-950/50 p-4 rounded-xl border border-slate-850">
                  <span className="text-[9px] text-yellow-400 font-mono font-bold uppercase block tracking-wider">
                    Custom Shield Master Settings
                  </span>
                  <p className="text-[10.5px] text-slate-400 leading-normal font-mono">
                    Select the core skills you want displayed on your shields.io profile badges. We pre-selected Rhod Gabriel's BSCpE stack!
                  </p>

                  <div className="flex flex-wrap gap-1.5 max-h-[130px] overflow-y-auto p-2 bg-slate-900 rounded border border-slate-800">
                    {["TypeScript", "JavaScript", "Python", "Go", "C++", "C", "C#", "React", "Next.js", "Node.js", "Express", "Docker", "Git", "PostgreSQL", "SQLite", "MongoDB", "Figma", "AWS", "GitHub Actions", "Vite", "Kubernetes"].map(skillName => {
                      const isSelected = userData.selectedSkills.includes(skillName);
                      return (
                        <button
                          key={skillName}
                          onClick={() => {
                            const isIncluded = userData.selectedSkills.includes(skillName);
                            const updated = isIncluded ? userData.selectedSkills.filter(s => s !== skillName) : [...userData.selectedSkills, skillName];
                            setUserData({ ...userData, selectedSkills: updated });
                          }}
                          className={`px-2 py-1 rounded text-[10px] font-mono border font-bold transition-all ${
                            isSelected 
                              ? 'bg-sky-500/10 border-sky-500 text-sky-300' 
                              : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          {skillName}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* AI synthesis generator view */}
              {activeStep.id === "step_05_ai" && (
                <div className="space-y-4 bg-slate-950/80 p-4 rounded-xl border border-sky-900/30">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-yellow-400 font-bold font-mono uppercase tracking-wider flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-sky-400" /> PROMPT MATRIX SETTINGS
                    </span>
                    <span className="text-[9px] font-mono text-slate-500">
                      GEMINI DEPLOYED FLASH
                    </span>
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[9px] text-slate-400 mb-1">EXPERIENCE LEVEL</label>
                        <select
                          value={userData.experienceLevel}
                          onChange={(e) => setUserData({ ...userData, experienceLevel: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-800 text-white rounded px-2 py-1 focus:outline-none"
                        >
                          <option value="Junior/Entry-Level">Junior/Entry-Level</option>
                          <option value="Associate student developer">Associate student developer</option>
                          <option value="Mid-Level student Engineer">Mid-Level student Engineer</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[9px] text-slate-400 mb-1">README STYLE TONE</label>
                        <select
                          value={userData.tone}
                          onChange={(e) => setUserData({ ...userData, tone: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-800 text-white rounded px-2 py-1 focus:outline-none"
                        >
                          <option value="highly professional sci-fi">Professional Sci-Fi</option>
                          <option value="clean, modern, minimalist">Clean Minimalist</option>
                          <option value="technical computer engineer">Hardware & Devops Focused</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">GITHUB PREFERRED USERNAME TARGET</label>
                      <input 
                        type="text"
                        value={userData.githubUsername}
                        onChange={(e) => setUserData({ ...userData, githubUsername: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-800 text-white rounded px-2.5 py-1.5 focus:outline-none"
                      />
                    </div>
                  </div>

                  {synthesisError && (
                    <div className="bg-red-950/40 border border-red-500/50 text-red-300 p-2 text-xs rounded font-mono">
                      <strong>AI DOWNLINK DISRUPTION:</strong> {synthesisError}
                    </div>
                  )}

                  <button
                    onClick={runAiSynthesis}
                    disabled={isSynthesizing}
                    className="w-full bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-slate-950 font-black font-mono py-3.5 px-5 rounded-xl border-none flex items-center justify-center gap-2 transition-all shadow-[0_4px_15px_rgba(56,189,248,0.2)] disabled:opacity-50"
                  >
                    {isSynthesizing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>INTERFACING SPACE PIPELINES...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>GENERATE PORTFOLIO MARKDOWN</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {/* Tips block */}
              <div className="bg-slate-950/30 p-3 rounded-lg border border-slate-850/60 font-mono text-[11px] text-slate-400 space-y-1">
                <span className="font-bold text-sky-450 uppercase block text-[10px]">TIPS FOR RECRUITERS & WORKSPACE:</span>
                <ul className="list-disc pl-4 space-y-0.5">
                  {activeStep.tips.map((tip, i) => (
                    <li key={i}>{tip}</li>
                  ))}
                </ul>
              </div>

            </div>

            {/* PREVIOUS / NEXT STEPPING GUIDE CONTROLLER */}
            <div className="mt-6 pt-4 border-t border-slate-850 flex justify-between gap-3 text-xs">
              <button
                disabled={activeStep.phaseId === 1}
                onClick={() => {
                  const prev = steps.find(s => s.phaseId === activeStep.phaseId - 1);
                  if (prev) setActiveStepId(prev.id);
                }}
                className="px-3.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg font-mono text-slate-400 hover:text-white disabled:opacity-20"
              >
                ◀ PREVIOUS STAGE
              </button>
              
              <div className="flex items-center gap-1.5 font-mono">
                {steps.map(st => (
                  <div 
                    key={st.id} 
                    className={`w-2 h-2 rounded-full transition-all ${
                      st.id === activeStepId 
                        ? 'bg-sky-400 scale-125 shadow-[0_0_8px_#38bdf8]' 
                        : st.isCompleted 
                          ? 'bg-emerald-400' 
                          : 'bg-slate-800'
                    }`} 
                  />
                ))}
              </div>

              <button
                disabled={activeStep.phaseId === steps.length || !steps.find(s => s.phaseId === activeStep.phaseId + 1)?.isUnlocked}
                onClick={() => {
                  const next = steps.find(s => s.phaseId === activeStep.phaseId + 1);
                  if (next) setActiveStepId(next.id);
                }}
                className="px-3.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg font-mono text-sky-400 hover:text-sky-300 disabled:opacity-20"
              >
                NEXT STAGE ▶
              </button>
            </div>
          </div>
        </section>

        {/* RIGHT COLUMN: PRE-COMPILED SCI-FI SECTIONS & MANUAL EXAMPLES (COL-SPAN-3) */}
        <section className="lg:col-span-3 flex flex-col gap-6">
          
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 relative overflow-hidden backdrop-blur-sm flex-1 flex flex-col justify-between">
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-sky-400 uppercase font-mono tracking-wider mb-2 flex items-center gap-1.5">
                <Briefcase className="w-4 h-4 animate-bounce" />
                <span>RHOD GABRIEL'S HIGHLIGHTS</span>
              </h3>
              
              <p className="text-[10.5px] text-slate-400 leading-normal font-mono">
                Quick copyable custom markdown grids pre-optimized for a Computer Engineer student. Insert these directly into your master README templates:
              </p>

              <div className="space-y-3 font-mono">
                
                {/* Section A */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-white text-[11px] font-bold">💻 HARDWARE & COGNITIVE STACK</span>
                    <span className="text-[9px] text-emerald-400">MARKDOWN</span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    A formatted section specifying microcontroller programming (C/C++), circuit design, and Web GUI integration.
                  </p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`### ⚡ Hardware Matrix & IoT Stack\n- **Microcontrollers**: STM32, ESP32, Arduino (C/C++ Architecture)\n- **Hardware & Circuits**: PCB CAD, Digital Logics, Oscilloscope Diagnostic\n- **Embedded Communication**: I2C, SPI, UART, Modbus TCP\n- **Web Deflectors**: React WebSocket telemetry, node-serialport, JSON interfaces`);
                      addLog("Copied hardware markdown details to clipboard.");
                    }}
                    className="w-full text-center text-[10px] hover:text-white text-sky-400 bg-slate-900 border border-slate-800 py-1 rounded"
                  >
                    SELECT & COPY
                  </button>
                </div>

                {/* Section B */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-white text-[11px] font-bold">📡 CONTACT & COMM COORDINATES</span>
                    <span className="text-[9px] text-emerald-400">MARKDOWN</span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Perfect alignment grid with real recruiter assets ready to paste.
                  </p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`### 📡 Connectivity Core / Communication Gates\n- **Sector Phone line**: \`09945886983\`\n- **Primary Email Box**: [rhodgabrieljavellana@gmail.com](mailto:rhodgabrieljavellana@gmail.com)\n- **GitHub Interface**: [github.com/rhodgabriel-dev](https://github.com/rhodgabriel-dev)\n- **Deploy Status**: BS Computer Engineering Student [Adaptation Rank: FAST LEARNER]`);
                      addLog("Copied Connectivity coordinates Markdown to clipboard.");
                    }}
                    className="w-full text-center text-[10px] hover:text-white text-sky-400 bg-slate-900 border border-slate-800 py-1 rounded"
                  >
                    SELECT & COPY
                  </button>
                </div>

                {/* Section C */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-white text-[11px] font-bold">📊 GITHUB STATS OVERLAYS</span>
                    <span className="text-[9px] text-emerald-400">MARKDOWN</span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Generates markdown to render your real-time commits, stars, & language ranks automatically!
                  </p>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`### 📊 Diagnostic Telemetry Scan\n\n![Rhod's GitHub Stats](https://github-readme-stats.vercel.app/api?username=rhodgabriel-dev&show_icons=true&theme=tokyonight)\n![Most Used Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=rhodgabriel-dev&layout=compact&theme=tokyonight)`);
                      addLog("Copied Live stats Markdown to clipboard.");
                    }}
                    className="w-full text-center text-[10px] hover:text-white text-sky-400 bg-slate-900 border border-slate-800 py-1 rounded"
                  >
                    SELECT & COPY
                  </button>
                </div>

              </div>
            </div>

            <div className="bg-slate-950 rounded border border-slate-850 p-3 mt-4 text-[10.5px]">
              <div className="text-white font-bold mb-1">RECRUITER FEEDBACK:</div>
              <div className="text-slate-450 italic leading-relaxed">
                "Having standard shields.io badges paired with hardware/embedded-specific listings instantly differentiates Rhod from standard Web developers."
              </div>
            </div>
          </div>

        </section>

      </main>

      {/* PORTFOLIO README OUTPUT INTERACTIVE DISPLAY AND GENERATED VIEW SECTION */}
      {synthesizedMarkdown && (
        <section className="bg-slate-950 border-t border-sky-900/60 p-6 relative z-10">
          <div className="max-w-7xl mx-auto space-y-4">
            
            <div className="flex items-center justify-between flex-wrap gap-4 pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-lg font-bold font-mono text-white flex items-center gap-1.5">
                  <CheckCircle className="text-emerald-400 w-5 h-5 animate-pulse" />
                  <span>SYNTHESIZED SCI-FI GITHUB PROFILE README.md</span>
                </h2>
                <p className="text-xs text-slate-400 font-mono">
                  Copy and paste this markdown directly into your GitHub account profile secret repository space (usually <code className="text-sky-305 text-white bg-slate-900 px-1 py-0.5 rounded">github.com/{userData.githubUsername}/{userData.githubUsername}</code>)!
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={copyToClipboard}
                  className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold font-mono text-xs px-5 py-2.5 rounded-xl border-none flex items-center gap-1.5 active:scale-95 transition-all shadow-[0_0_15px_rgba(56,189,248,0.2)]"
                >
                  {copiedStatus ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>COPIED SUCCESSFULLY</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>COPY MARKDOWN CODE</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Markdown Display Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest block mb-2 font-bold">
                  RAW MARKDOWN MATRIX
                </span>
                <textarea
                  readOnly
                  value={synthesizedMarkdown}
                  className="w-full flex-1 min-h-[350px] bg-slate-950 border border-slate-850 p-4 text-slate-100 font-mono text-xs rounded-xl focus:outline-none focus:border-sky-500 leading-relaxed overflow-y-auto"
                />
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest block mb-2 font-bold">
                  RECRUITER RENDER PREVIEW
                </span>
                <div className="w-full flex-1 min-h-[350px] bg-slate-350 text-slate-950 p-6 rounded-xl leading-relaxed overflow-y-auto max-h-[500px]">
                  <div className="prose max-w-none text-slate-900">
                    <h1 className="text-xl font-bold font-mono border-b border-slate-400 pb-2 text-slate-950 mb-2 tracking-tight">
                      🛰️ CORE ANCHOR // {userData.name}
                    </h1>
                    <p className="text-xs text-indigo-700 font-mono font-bold mb-4">
                      DEPLOYED ROLE: {userData.role} (Experience Level: {userData.experienceLevel})
                    </p>
                    
                    <div className="bg-slate-200 p-3.5 rounded border border-slate-300 mb-4 whitespace-pro-wrap font-sans text-xs font-semibold text-slate-800">
                      {userData.bioHighlights}
                    </div>

                    <h3 className="text-sm font-semibold font-mono text-slate-950 mt-4 mb-2 uppercase">
                       ⚡ POWER SOURCES (Core Skills Stack / Shields)
                    </h3>
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {userData.selectedSkills.map(skill => {
                        return (
                          <span key={skill} className="bg-slate-900 text-slate-100 px-2.5 py-0.5 rounded border border-slate-800 text-[10px] font-mono">
                            {skill}
                          </span>
                        );
                      })}
                    </div>

                    <h3 className="text-sm font-semibold font-mono text-slate-950 mt-4 mb-1 uppercase">
                       📡 CONNECTIVITY GATES (Contacts & Links)
                    </h3>
                    <ul className="list-disc pl-5 space-y-1 text-xs text-slate-800 font-semibold">
                      <li><strong>Sector Email Box:</strong> rhodgabrieljavellana@gmail.com</li>
                      <li><strong>Telepathy Comm Line:</strong> 09945886983</li>
                      <li><strong>GitHub Base:</strong> https://github.com/{userData.githubUsername}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </section>
      )}

      {/* FOOTER */}
      <footer className="border-t border-slate-900 bg-slate-950/60 px-6 py-6 mt-12 relative overflow-hidden z-10 font-mono text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 pointer-events-auto">
          <div className="space-y-1">
            <span className="text-sky-400 font-black tracking-widest text-[11px] block uppercase">
              Rhod Gabriel // Github Portfolio Architect
            </span>
            <p className="text-slate-400 text-[10px]">
              Combining digital hardware architecture with low-bloat streamlined application layers.
            </p>
          </div>
          <div className="flex gap-4 text-slate-500">
            <span>Age: 20</span>
            <span>•</span>
            <span>Computer Engineering Student</span>
            <span>•</span>
            <span>Fast Learner Protocol</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
