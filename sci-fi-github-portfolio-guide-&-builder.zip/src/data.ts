import { Step, TechBadge, TechCategory, TerminalUpgrade } from "./types";

export const TECH_CATEGORIES: TechCategory[] = [
  { id: "languages", label: "Core Engines (Languages)", iconName: "Code2" },
  { id: "frameworks", label: "Structural Matrices (Frameworks)", iconName: "Cpu" },
  { id: "databases", label: "Core Storage (Databases)", iconName: "Database" },
  { id: "tools", label: "Support Systems (Tools & Ops)", iconName: "Wrench" },
];

export const TECH_BADGES: TechBadge[] = [
  { name: "TypeScript", category: "languages", badgeSlug: "typescript-%23007ACC", hexColor: "007ACC" },
  { name: "JavaScript", category: "languages", badgeSlug: "javascript-%23F7DF1E", hexColor: "F7DF1E" },
  { name: "Python", category: "languages", badgeSlug: "python-3670A0", hexColor: "3670A0" },
  { name: "Go", category: "languages", badgeSlug: "go-%2300ADD8", hexColor: "00ADD8" },
  { name: "Rust", category: "languages", badgeSlug: "rust-%23000000", hexColor: "000000" },
  { name: "Java", category: "languages", badgeSlug: "java-%23ED8B00", hexColor: "ED8B00" },
  { name: "C++", category: "languages", badgeSlug: "c%2B%2B-%2300599C", hexColor: "00599C" },
  { name: "Kotlin", category: "languages", badgeSlug: "kotlin-%237F52FF", hexColor: "7F52FF" },
  
  { name: "React", category: "frameworks", badgeSlug: "react-%2320232a", hexColor: "61DAFB" },
  { name: "Next.js", category: "frameworks", badgeSlug: "next.js-%23000000", hexColor: "FFFFFF" },
  { name: "Vue.js", category: "frameworks", badgeSlug: "vue-%234FC08D", hexColor: "4FC08D" },
  { name: "Angular", category: "frameworks", badgeSlug: "angular-%23DD0031", hexColor: "DD0031" },
  { name: "Svelte", category: "frameworks", badgeSlug: "svelte-%23FF3E00", hexColor: "FF3E00" },
  { name: "Node.js", category: "frameworks", badgeSlug: "node.js-%2343853D", hexColor: "43853D" },
  { name: "Django", category: "frameworks", badgeSlug: "django-%23092E20", hexColor: "092E20" },
  { name: "Spring", category: "frameworks", badgeSlug: "spring-%236DB33F", hexColor: "6DB33F" },

  { name: "PostgreSQL", category: "databases", badgeSlug: "postgresql-%23316192", hexColor: "316192" },
  { name: "MongoDB", category: "databases", badgeSlug: "mongodb-%234ea94b", hexColor: "4ea94b" },
  { name: "Redis", category: "databases", badgeSlug: "redis-%23DD0031", hexColor: "DD0031" },
  { name: "MySQL", category: "databases", badgeSlug: "mysql-%2300f", hexColor: "00758F" },
  { name: "SQLite", category: "databases", badgeSlug: "sqlite-%2307405e", hexColor: "07405E" },
  { name: "Cassandra", category: "databases", badgeSlug: "cassandra-%231287B1", hexColor: "1287B1" },

  { name: "Docker", category: "tools", badgeSlug: "docker-%230db7ed", hexColor: "0db7ed" },
  { name: "Kubernetes", category: "tools", badgeSlug: "kubernetes-%23326ce5", hexColor: "326ce5" },
  { name: "Git", category: "tools", badgeSlug: "git-%23F05033", hexColor: "F05033" },
  { name: "AWS", category: "tools", badgeSlug: "aws-%23FF9900", hexColor: "FF9900" },
  { name: "Google Cloud", category: "tools", badgeSlug: "google_cloud-%234285F4", hexColor: "4285F4" },
  { name: "GitHub Actions", category: "tools", badgeSlug: "github%20actions-%232088FF", hexColor: "2088FF" },
  { name: "Terraform", category: "tools", badgeSlug: "terraform-%235843U7", hexColor: "7B42BC" },
];

export const INITIAL_STEPS: Step[] = [
  {
    id: "step_01_repo",
    phaseId: 1,
    title: "Primary Core Genesis (The Repository)",
    subtitle: "Unlock the GitHub secret profile vector",
    description: "GitHub has a beautiful hidden feature: if you create a public repository with the EXACT same name as your GitHub account, the README.md of that repository automatically renders directly in your main profile dashboard!",
    systemAction: "Verify repository initialization parameters",
    completionCredits: 50,
    markdownSnippet: "Status: Awaiting Username Activation",
    isUnlocked: true,
    isCompleted: false,
    tasks: [
      { id: "t1", label: "Double check your exact GitHub username capitalization", completed: false },
      { id: "t2", label: "Create a NEW repository on GitHub with this exact spelling", completed: false },
      { id: "t3", label: "Set the repository visibility strictly to PUBLIC", completed: false },
      { id: "t4", label: "Check the checkbox to 'Initialize this repository with a README'", completed: false },
    ],
    tips: [
      "If done correctly, GitHub displays a special cosmic kitty banner saying you found a secret release!",
      "Visiting https://github.com/your-username/your-username should load properly."
    ]
  },
  {
    id: "step_02_hero",
    phaseId: 2,
    title: "Structural Bio Deflector",
    subtitle: "Establish command and primary functions",
    description: "Recruiters generally look at a profile for less than 10 seconds. You need a futuristic yet instantly legible overview outlining exactly what role you operate, where you are deployed, and your core technical philosophy.",
    systemAction: "Generate introduction matrices",
    completionCredits: 50,
    isUnlocked: false,
    isCompleted: false,
    tasks: [
      { id: "t5", label: "Define your clear primary title (e.g., Lead Frontend Archeologist)", completed: false },
      { id: "t6", label: "Draft a high-impact 1-sentence tagline describing your value", completed: false },
      { id: "t7", label: "Draft 3 specific bullet points containing your current project focuses", completed: false }
    ],
    tips: [
      "Keep it brief and active. Avoid vague summaries like 'Motivated developer looking for work'.",
      "Style with high-contrast text blockquotes for maximum visibility."
    ]
  },
  {
    id: "step_03_badges",
    phaseId: 3,
    title: "Deflector Fields (Shield Matrices)",
    subtitle: "Configure visual tech badges",
    description: "Using standard visual badges from shields.io makes your skills section highly scannable. It quickly proves to technical recruiters what core engines, databases, and frameworks you have mastered without reading paragraphs.",
    systemAction: "Recalibrate shields",
    completionCredits: 50,
    isUnlocked: false,
    isCompleted: false,
    tasks: [
      { id: "t8", label: "Pick your core programming languages in our list below", completed: false },
      { id: "t9", label: "Include standard tools and deployment engines you know", completed: false },
      { id: "t10", label: "Generate optimized markdown shield components", completed: false }
    ],
    tips: [
      "Group shields cleanly (e.g. Frontend, Backend, Devops) so they align in nice rows.",
      "Don't add skills you can't describe in an interview. Keep it genuine."
    ]
  },
  {
    id: "step_04_stats",
    phaseId: 4,
    title: "Telemetry & Diagnostic Sensors",
    subtitle: "Add live GitHub stats, languages, and streaks",
    description: "Make your profile dynamic by linking third-party stats engines like 'github-readme-stats'. These pull live telemetry from your public commits, stars, pull-requests, and languages directly to your README!",
    systemAction: "Integrate telemetry pipelines",
    completionCredits: 50,
    isUnlocked: false,
    isCompleted: false,
    tasks: [
      { id: "t11", label: "Add a main dynamic stats block to your readme skeleton", completed: false },
      { id: "t12", label: "Add the 'Most Used Languages' dial tracker", completed: false },
      { id: "t13", label: "Select a matching visual palette coordinate (e.g., cyberpunk, midnight)", completed: false }
    ],
    tips: [
      "You don't need to host anything! Simply write static image links that query stats servers.",
      "Be aware that if your GitHub username changes, you must update the URLs instantly."
    ]
  },
  {
    id: "step_05_ai",
    phaseId: 5,
    title: "AI Synthesis (The Matrix Assembly)",
    subtitle: "Generate your custom recruiter-friendly portfolio README",
    description: "Provide details into our AI Synthesizer below, and we will formulate an exceptional, optimized sci-fi themed Markdown portfolio README tailored with shields, stats templates, and clear, legible recruiter guides.",
    systemAction: "Engage Gemini Synthesizer",
    completionCredits: 100,
    isUnlocked: false,
    isCompleted: false,
    tasks: [
      { id: "t14", label: "Input your target role and resume highlights in our deck", completed: false },
      { id: "t15", label: "Press the 'AI SYNTHESIZE' interface button", completed: false },
      { id: "t16", label: "Receive, copy, and install your cosmic README file on GitHub!", completed: false }
    ],
    tips: [
      "Review the output carefully to customize links to your real portfolio projects.",
      "Push to your master/main branch and refresh your GitHub profile page to see it live!"
    ]
  }
];

export const TECHNICAL_UPGRADES: TerminalUpgrade[] = [
  {
    id: "up_scanline",
    title: "[CRT SCANLINE GENERATOR]",
    description: "Overlay retro television phosphor scanning sweeps and glass curves.",
    cost: 30,
    isPurchased: false,
    type: "crt-filter",
    value: "retro-flicker"
  },
  {
    id: "up_alert",
    title: "[EMERGENCY BEACON KLAXON]",
    description: "Installs a togglable blinking red alert structural warning system.",
    cost: 50,
    isPurchased: false,
    type: "klaxon-siren",
    value: "emergency-red"
  },
  {
    id: "up_green",
    title: "[GREEN PROTOCOL OVERLAY]",
    description: "Switches current display theme matrix strictly to retro terminal green.",
    cost: 75,
    isPurchased: false,
    type: "color-mod",
    value: "matrix-green"
  },
  {
    id: "up_frequency",
    title: "[AUDIO FREQUENCY OVERCLOCK]",
    description: "Retunes system sound oscillators for high-frequency cyberpunk ticks.",
    cost: 100,
    isPurchased: false,
    type: "audio-freq",
    value: "overclocked-pitch"
  }
];
