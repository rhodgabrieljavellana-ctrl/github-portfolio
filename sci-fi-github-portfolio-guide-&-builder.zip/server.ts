import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API client only when needed to prevent direct crashes on startup if key is missing
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY secret is required on the server side to power the AI Portfolio Bio Synthesizer.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// REST route for synthesizing the portfolio README
app.post("/api/synthesize-portfolio", async (req: express.Request, res: express.Response): Promise<void> => {
  try {
    const { name, githubUsername, role, bioHighlights, selectedSkills, selectedTheme, experienceLevel, tone } = req.body;

    if (!githubUsername) {
      res.status(400).json({ error: "GitHub Username is required." });
      return;
    }

    const ai = getAiClient();

    // Construct highly targeted prompt for a sci-fi yet recruiter-friendly markdown profile
    const prompt = `
Generate a world-class, premium, and highly visually polished GitHub profile README.md in Markdown.
The aesthetic requested by the user is: "Sci-Fi themed, futuristic yet professional and user-friendly for recruiters to navigate easily."
Make sure the tone is "${tone || 'futuristic and confident'}".
User Data:
- Name: ${name || githubUsername}
- GitHub Username: ${githubUsername}
- Desired Role/Title: ${role || 'Full Stack Engineer'}
- Experience Level: ${experienceLevel || 'Mid-Level'}
- Core Bio Highlights: ${bioHighlights || 'Building next-generation digital ecosystems.'}
- Selected Tech Stack / Skills: ${(selectedSkills || []).join(", ")}
- Preferred Theme Color Accent: ${selectedTheme || 'cyberpunk neon-blue'}

Guidelines for the Markdown:
1. Include a futuristic Header styled beautifully (e.g., matching shields, cool ASCII-art style text or bold stylized display header).
2. Integrate a clean, organized "Technical Matrix" (using shields.io badges or a beautifully formatted markdown list/grid by category) containing their selected tech stack. Don't crowd too many badges - group them into: "Core Core-Engines (Languages)", "Structural Matrices (Frameworks)", "Support Subsystems (Tools/Databases)".
3. Add an "Active Directives / Featured Projects" section with clean, readable placeholders or examples showing high-quality projects.
4. Integrate dynamic GitHub statistics cards using standard markdown templates (e.g., github-readme-stats or github-readme-streak-stats). Wrap them with their actual GitHub username: ${githubUsername}.
5. Use highly immersive, professional sci-fi terminology for section names, but immediately follow with clean, highly legible descriptions so a recruiter knows exactly what it means. For example:
   - "📡 CONNECTIVITY GATES (Contacts & Links)" rather than just "Socials"
   - "⚡ POWER SOURCES (Languages & Core Skills)" rather than "Tech Stack"
   - "🌌 ORBITAL MISSIONS (Featured Projects)" rather than "Projects"
   - "📊 DIAGNOSTIC SCAN (GitHub Stats)" rather than "My Stats"
6. Ensure no broken HTML is outputted. All images should look perfect.
7. Return ONLY the Markdown text. Do not add markdown code blocks (like \`\`\`markdown) wrapped around it, just start directly with the README content so it can be copied directly.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    const markdownText = response.text || "";
    res.json({ markdown: markdownText });
  } catch (error: any) {
    console.error("Synthesize portfolio error:", error);
    res.status(500).json({ 
      error: error.message || "An unexpected error occurred during synthesis.",
      details: "Ensure your developer configured the GEMINI_API_KEY secret in Settings > Secrets."
    });
  }
});

// Serve API configuration details
app.get("/api/config", (req, res) => {
  res.json({
    hasApiKey: !!process.env.GEMINI_API_KEY,
    currentTime: "2026-05-27T13:09:31Z",
  });
});

// Configure Vite or Static server
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Vite server middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static production files from /dist...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

setupServer();
